import UIKit

//var dogName: String? = nil
//var catName: String? = "Dora"
//var myHouse: String? = nil
//var myTV: String? = ""
//let myTVUnwrapped: String = myTV!
//let myHouseUnwrapped: String = myHouse!
//Execution was interrupted

var price: Int? = nil
var myFavFruit: String? = "Strawberry"
if let priceUnwrapped = price{
    print("This item's price is {price}.")
}else{
    print("This item is not for sale!")
}
if let priceUnwrapped = price, let myFavFruitUnwrapped = myFavFruit{
    print("The \(String(describing: myFavFruit))'s price is {price}.")
}else{
    print("Error!")
}

guard let priceUnwrapped = price else{
    print("Unavailable")
    fatalError()
}
print("This item's price is \(priceUnwrapped).")
guard let priceUnwrapped = price, let myFavFruitUnwrapped = myFavFruit else{
    print("Unavailable")
    fatalError()
}
print("The \(String(describing: myFavFruit))'s price is \(String(describing: price))")
let realPrice = price ?? 0

var myCandies: [String] = []
myCandies += ["chocolatemilk", "mint", "caramel"]
var myCandiesSet: Set<String>
myCandiesSet = ["chocolatemilk", "mint", "caramel"]
var leftCandies: [String] = ["strawberry", "brownie"]
myCandiesSet.formUnion(leftCandies)
var months: [Int:String]
months = [1:"January", 2:"Febuary", 3:"March", 4:"April", 5:"May", 6:"June", 7:"July", 8:"August", 9:"September", 10:"October", 11:"November", 12:"December"]
print(months[14] ?? "none")

func findMinMax(numArray arrayInt: [Int]) -> (Int, Int)? {
    if (arrayInt.isEmpty) {
        return nil
    }
    var currentMin: Int = arrayInt[0]
    var currentMax: Int = arrayInt[0]
    
    for int in arrayInt {
        if (currentMin > int) {
            currentMin = int
        }
        if (currentMax < int) {
            currentMax = int
        }
    }
    return (currentMax, currentMin)
}
findMinMax(numArray: [-1,1,2,3,4,5,6,7])

var numbers: [Int] = [1, 2, 3, 4, 5]
numbers.append(6)
numbers.remove(at:1)
print(numbers)

var studentNames: [String: Int] = ["John": 90, "Jane": 85, "Jake": 88]
print(studentNames["Jane"])
var uniqueNumbers: Set<Int> = [1, 2, 3, 4, 5]
//uniqueNumbers.insert(5)
print(uniqueNumbers)

var fruits: [String] = ["Apple", "Banana", "Cherry"]
for fruit in fruits {
    print(fruit)
}

var num = 5
while num > 0 {
    print(num)
    num -= 1
}

var ages: [String: Int] = ["Alice": 30, "Bob": 25, "Charlie": 35]

func addNumbers(num1:Int, num2:Int) -> Int {
    return (num1+num2)
}

print(addNumbers(num1: 8, num2: 7))
