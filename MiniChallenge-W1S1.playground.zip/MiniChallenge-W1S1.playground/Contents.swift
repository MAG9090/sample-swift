import UIKit

let myNum: Int = 5
var num: Int = 10
let aNum = 0
print(myNum)
print(num)
print(aNum)

let day = 1
let title = "iOS Club Day \(day)"
print(title)

var myName: String = "Magnolia"
var myAge: Int = 18
var intro: String = "Hi my name is \(myName) and I'm \(myAge)."
print(intro)
let friendName: String = "Glenne"
let friendYear: String = "Freshman"
let friendDay: String = "good"
let friendIntro: String = "My friend's name is \(friendName) and she is \(friendYear). She had a \(friendDay) day"
print(friendIntro)

var a = 3
var b = 1
var c = a+b
print("c is now \(c)")
c += 10
print("c is now \(c)")
c *= 2
print("c is now \(c)")
c -= 7
print("c is now \(c)")
var d = c%2

if a>b{
    print(a)
}
else{
    print(b)
}
if a>b && a>c{
    print(a)
}
else if b>a && b>c{
    print(b)
}
else{
    print(c)
}
if a%2 == 0{
    print("iOS Club")
}
else{
    print("Unlucky")
}
guard a>b else{
    print("Oops")
    fatalError()
}

