import UIKit

var greeting = "Hello, playground"
func sayHello() {
    print("Hello")
}
var greet = sayHello
greet
sayHello()
let sayHelloClosure = {print("Hello there!")}
sayHelloClosure

let sayHelloClosureWithParameters = {(yourName: String)->() in
    print("Hello there, \(yourName)")
}
sayHelloClosureWithParameters("Glenne")
let sayHelloClosureWithParameterAndRet = {(name: String) ->(String) in
    return "Hello there, \(name)"
}
sayHelloClosureWithParameterAndRet("Glenne")
func mySeatingArrangement(neighbor: [String])->(){
    print("I sit next to \(neighbor[0]) and sit next to \(neighbor[1])")
}
mySeatingArrangement(neighbor: ["Glenne" , "Magnolia"])

var sumOfInt = {(num1: Int, num2: Int)->(Int) in
    return num1+num2
}

var first30Fibonacci: [Int]
let myRange = 1..<30

myRange.map({ i in
    // Below code finds number at index i of the fibonacci sequence
    
    var first: Int = 0
    var second: Int = 1
    
    for _ in 0...i {
        let prev = first
        first = second
        second = prev + first
    }

    return first
})


func map(myArray: [String], replacement:     ((String) -> String)   ) -> [String] {
    var newArray: [String] = []
    for element in myArray {
        newArray.append( replacement(element) )
    }
    return newArray
}
